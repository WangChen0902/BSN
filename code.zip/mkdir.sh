mkdir -p ./output/PEM_results
mkdir -p ./output/TEM_results
mkdir -p ./output/PGM_proposals
mkdir -p ./output/PGM_feature



