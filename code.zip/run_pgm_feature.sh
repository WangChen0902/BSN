nohup python PGM_feature_generation.py 0 2500 &
nohup python PGM_feature_generation.py 2500 5000 &
nohup python PGM_feature_generation.py 5000 7500 &
nohup python PGM_feature_generation.py 7500 10000 &
nohup python PGM_feature_generation.py 10000 12500 &
nohup python PGM_feature_generation.py 12500 15000 &
nohup python PGM_feature_generation.py 15000 17500 &
nohup python PGM_feature_generation.py 17500 20000 &
echo "please wait for feature generation"

